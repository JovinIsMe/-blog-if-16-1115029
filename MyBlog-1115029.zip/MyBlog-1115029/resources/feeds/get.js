dpd.articles.get({$sort: {updatedAt: -1}}, function(result,err) {
    if(err) cancel(400, "Something Error");
    setResult(result);
});